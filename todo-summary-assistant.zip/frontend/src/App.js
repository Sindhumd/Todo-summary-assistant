import React, { useEffect, useState } from 'react';
import TodoForm from './components/TodoForm';
import TodoList from './components/TodoList';
import axios from 'axios';

function App() {
  const [todos, setTodos] = useState([]);
  const [message, setMessage] = useState('');

  const fetchTodos = async () => {
    const res = await axios.get('http://localhost:5000/todos');
    setTodos(res.data);
  };

  const addTodo = async (text) => {
    await axios.post('http://localhost:5000/todos', { text });
    fetchTodos();
  };

  const deleteTodo = async (id) => {
    await axios.delete(`http://localhost:5000/todos/${id}`);
    fetchTodos();
  };

  const summarizeTodos = async () => {
    const res = await axios.post('http://localhost:5000/summarize');
    setMessage(res.data.success ? 'Summary sent to Slack!' : 'Failed to send summary.');
  };

  useEffect(() => {
    fetchTodos();
  }, []);

  return (
    <div>
      <h1>Todo Summary Assistant</h1>
      <TodoForm addTodo={addTodo} />
      <TodoList todos={todos} deleteTodo={deleteTodo} />
      <button onClick={summarizeTodos}>Summarize & Send to Slack</button>
      <p>{message}</p>
    </div>
  );
}

export default App;