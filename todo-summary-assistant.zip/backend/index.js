const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
require('dotenv').config();

const app = express();
const port = process.env.PORT || 5000;

app.use(cors());
app.use(bodyParser.json());

const todos = [];

app.get('/todos', (req, res) => res.json(todos));
app.post('/todos', (req, res) => {
  const { text } = req.body;
  const newTodo = { id: Date.now(), text };
  todos.push(newTodo);
  res.json(newTodo);
});
app.delete('/todos/:id', (req, res) => {
  const { id } = req.params;
  const index = todos.findIndex(todo => todo.id == id);
  if (index >= 0) todos.splice(index, 1);
  res.sendStatus(200);
});

app.post('/summarize', async (req, res) => {
  const { default: axios } = await import('axios');
  const messages = todos.map(todo => todo.text).join('\n');

  try {
    const summaryRes = await axios.post('https://api.openai.com/v1/chat/completions', {
      model: "gpt-3.5-turbo",
      messages: [{ role: "user", content: `Summarize these todos:\n${messages}` }]
    }, {
      headers: {
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
        'Content-Type': 'application/json'
      }
    });

    const summary = summaryRes.data.choices[0].message.content;

    await axios.post(process.env.SLACK_WEBHOOK_URL, {
      text: summary
    });

    res.json({ success: true });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ success: false });
  }
});

app.listen(port, () => console.log(`Server running on port ${port}`));